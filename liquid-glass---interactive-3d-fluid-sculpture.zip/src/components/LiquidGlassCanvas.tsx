import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GlassPreset } from '../utils/glassPhysics';
import { soundFx } from '../utils/audioSynthesizer';

interface LiquidGlassCanvasProps {
  preset: GlassPreset;
  viscosity: number;
  waveAmplitude: number;
  waveFrequency: number;
  ior: number;
  roughness: number;
  dispersion: number;
  autoRotate: boolean;
  cameraPreset: 'macro' | 'studio' | 'top' | 'reset' | null;
  onCameraPresetSettled?: () => void;
  onFpsUpdate?: (fps: number, triangles: number) => void;
  rippleTrigger: number;
}

// Pre-allocated scratch objects to ensure zero GC in animation loop
const _targetCamPos = new THREE.Vector3();
const _targetControlsTarget = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();
const _mouse = new THREE.Vector2();

/**
 * Procedurally generates a diamond knurled normal map for the machined metal pedestal.
 */
function createKnurledNormalMap(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = 'rgb(128, 128, 255)';
  ctx.fillRect(0, 0, size, size);

  const step = 16;
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgb(160, 110, 240)';

  for (let i = -size; i < size * 2; i += step) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + size, size);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(i + size, 0);
    ctx.lineTo(i, size);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 2);
  texture.colorSpace = THREE.NoColorSpace;
  return texture;
}

/**
 * Procedurally generates a soft radial contact shadow with caustics ring.
 */
function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const cx = size / 2;
  const cy = size / 2;

  // Dark central contact occlusion
  const gradient = ctx.createRadialGradient(cx, cy, 10, cx, cy, size / 2);
  gradient.addColorStop(0, 'rgba(0, 0, 0, 0.85)');
  gradient.addColorStop(0.28, 'rgba(0, 0, 0, 0.6)');
  gradient.addColorStop(0.55, 'rgba(0, 0, 0, 0.25)');
  gradient.addColorStop(0.85, 'rgba(0, 0, 0, 0.05)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, size, size);

  // Subtle outer caustic ring
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.38, 0, Math.PI * 2);
  ctx.lineWidth = 8;
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export const LiquidGlassCanvas: React.FC<LiquidGlassCanvasProps> = ({
  preset,
  viscosity,
  waveAmplitude,
  waveFrequency,
  ior,
  roughness,
  dispersion,
  autoRotate,
  cameraPreset,
  onCameraPresetSettled,
  onFpsUpdate,
  rippleTrigger,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const uniformsRef = useRef<{
    uTime: { value: number };
    uViscosity: { value: number };
    uAmplitude: { value: number };
    uFrequency: { value: number };
    uRippleOrigin: { value: THREE.Vector3 };
    uRippleTime: { value: number };
    uDispersion: { value: number };
    uGlassColor: { value: THREE.Color };
    uAttenuationColor: { value: THREE.Color };
  }>({
    uTime: { value: 0 },
    uViscosity: { value: viscosity },
    uAmplitude: { value: waveAmplitude },
    uFrequency: { value: waveFrequency },
    uRippleOrigin: { value: new THREE.Vector3(0, 0.85, 0) },
    uRippleTime: { value: 999.0 },
    uDispersion: { value: dispersion },
    uGlassColor: { value: new THREE.Color(preset.color) },
    uAttenuationColor: { value: new THREE.Color(preset.attenuationColor) },
  });

  const materialsRef = useRef<{
    glassMaterial?: THREE.MeshPhysicalMaterial;
    coreMaterial?: THREE.MeshStandardMaterial;
    ringMaterial?: THREE.MeshStandardMaterial;
    satMaterial?: THREE.MeshPhysicalMaterial;
    emitterMaterial?: THREE.MeshStandardMaterial;
  }>({});

  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const triggerRippleRef = useRef<() => void>(() => {});

  // Update uniforms when props change
  useEffect(() => {
    uniformsRef.current.uViscosity.value = viscosity;
    uniformsRef.current.uAmplitude.value = waveAmplitude;
    uniformsRef.current.uFrequency.value = waveFrequency;
    uniformsRef.current.uDispersion.value = dispersion;
    uniformsRef.current.uGlassColor.value.set(preset.color);
    uniformsRef.current.uAttenuationColor.value.set(preset.attenuationColor);
  }, [viscosity, waveAmplitude, waveFrequency, dispersion, preset]);

  // Update material properties when preset or glass parameters change
  useEffect(() => {
    const glassMat = materialsRef.current.glassMaterial;
    const coreMat = materialsRef.current.coreMaterial;
    const satMat = materialsRef.current.satMaterial;
    const emitterMat = materialsRef.current.emitterMaterial;

    if (glassMat) {
      glassMat.color.set(preset.color);
      glassMat.attenuationColor.set(preset.attenuationColor);
      glassMat.attenuationDistance = preset.attenuationDistance;
      glassMat.ior = ior;
      glassMat.roughness = roughness;
      glassMat.metalness = preset.metalness;
      glassMat.clearcoat = preset.clearcoat;
      glassMat.clearcoatRoughness = preset.clearcoatRoughness;
      glassMat.thickness = preset.thickness;
      glassMat.needsUpdate = true;
    }
    if (coreMat) {
      coreMat.color.set(preset.coreColor);
      coreMat.needsUpdate = true;
    }
    if (satMat) {
      satMat.color.set(preset.attenuationColor);
      satMat.attenuationColor.set(preset.color);
      satMat.needsUpdate = true;
    }
    if (emitterMat) {
      emitterMat.color.set(preset.coreColor);
      emitterMat.emissive.set(preset.coreColor);
      emitterMat.needsUpdate = true;
    }
  }, [preset, ior, roughness]);

  // Handle external ripple trigger
  useEffect(() => {
    if (rippleTrigger > 0) {
      triggerRippleRef.current();
    }
  }, [rippleTrigger]);

  // Camera preset transitions
  useEffect(() => {
    if (!cameraPreset || !cameraRef.current || !controlsRef.current) return;

    if (cameraPreset === 'macro') {
      _targetCamPos.set(0.1, 0.88, 2.3);
      _targetControlsTarget.set(0, 0.82, 0);
    } else if (cameraPreset === 'studio') {
      _targetCamPos.set(2.4, 1.8, 3.4);
      _targetControlsTarget.set(0, 0.7, 0);
    } else if (cameraPreset === 'top') {
      _targetCamPos.set(0.01, 4.4, 0.01);
      _targetControlsTarget.set(0, 0.65, 0);
    } else if (cameraPreset === 'reset') {
      _targetCamPos.set(0, 1.7, 4.2);
      _targetControlsTarget.set(0, 0.7, 0);
    }

    let progress = 0;
    const startTime = performance.now();
    const duration = 1200;
    const startCamPos = cameraRef.current.position.clone();
    const startTarget = controlsRef.current.target.clone();

    const animStep = () => {
      const elapsed = performance.now() - startTime;
      progress = Math.min(1, elapsed / duration);
      const ease = progress < 0.5 ? 4 * progress * progress * progress : 1 - Math.pow(-2 * progress + 2, 3) / 2;

      if (cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerpVectors(startCamPos, _targetCamPos, ease);
        controlsRef.current.target.lerpVectors(startTarget, _targetControlsTarget, ease);
        controlsRef.current.update();
      }

      if (progress < 1) {
        requestAnimationFrame(animStep);
      } else {
        onCameraPresetSettled?.();
      }
    };
    requestAnimationFrame(animStep);
  }, [cameraPreset, onCameraPresetSettled]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect Software WebGL (SwiftShader, llvmpipe, WARP) for headless/container safety
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 3. Scene & Camera setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#08090c');
    scene.fog = new THREE.FogExp2('#08090c', 0.08);

    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      50
    );
    camera.position.set(0, 1.7, 4.2);
    cameraRef.current = camera;

    // 4. Controls setup
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1.6;
    controls.maxDistance = 8.0;
    controls.maxPolarAngle = Math.PI / 2 + 0.05;
    controls.target.set(0, 0.7, 0);
    controlsRef.current = controls;

    // 5. Procedural Studio Environment (`RoomEnvironment` + `PMREMGenerator`)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 6. Lighting Rig: Warm Key + Cool Hemisphere + Rim Light
    const keyLight = new THREE.DirectionalLight('#fff5ea', 3.2);
    keyLight.position.set(4, 6, 3.5);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
      const d = 3;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
    }
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight('#80d0ff', 1.6);
    fillLight.position.set(-4, 3, -2);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight('#67e8f9', '#080c14', 1.2);
    scene.add(hemiLight);

    const rimLight = new THREE.PointLight('#a78bfa', 2.8, 10);
    rimLight.position.set(0, 3.5, -3);
    scene.add(rimLight);

    // 7. Composite 3–12 Part Procedural Model Group (`THREE.Group`)
    const heroGroup = new THREE.Group();
    heroGroup.position.set(0, 0, 0);
    scene.add(heroGroup);

    // Part 1: Main Hero Subject — Amorphous Molten Glass Vessel
    // Use SphereGeometry with fine subdivision for clean UVs and vertex wave displacement
    const glassGeometry = new THREE.SphereGeometry(1.22, isSoftwareGl ? 36 : 64, isSoftwareGl ? 28 : 48);

    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(preset.color),
      transmission: isSoftwareGl ? 0.35 : preset.transmission,
      transparent: true,
      opacity: isSoftwareGl ? 0.55 : 1.0,
      ior: preset.ior,
      roughness: preset.roughness,
      metalness: preset.metalness,
      clearcoat: preset.clearcoat,
      clearcoatRoughness: preset.clearcoatRoughness,
      thickness: preset.thickness,
      attenuationColor: new THREE.Color(preset.attenuationColor),
      attenuationDistance: preset.attenuationDistance,
      specularIntensity: 1.0,
      depthWrite: false,
    });

    // Inject dynamic fluid wave mathematics and Fresnel liquid shimmer
    glassMaterial.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = uniformsRef.current.uTime;
      shader.uniforms.uViscosity = uniformsRef.current.uViscosity;
      shader.uniforms.uAmplitude = uniformsRef.current.uAmplitude;
      shader.uniforms.uFrequency = uniformsRef.current.uFrequency;
      shader.uniforms.uRippleOrigin = uniformsRef.current.uRippleOrigin;
      shader.uniforms.uRippleTime = uniformsRef.current.uRippleTime;
      shader.uniforms.uDispersion = uniformsRef.current.uDispersion;
      shader.uniforms.uGlassColor = uniformsRef.current.uGlassColor;
      shader.uniforms.uAttenuationColor = uniformsRef.current.uAttenuationColor;

      shader.vertexShader = `
        uniform float uTime;
        uniform float uViscosity;
        uniform float uAmplitude;
        uniform float uFrequency;
        uniform vec3 uRippleOrigin;
        uniform float uRippleTime;
        uniform float uDispersion;
        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        ${shader.vertexShader}
      `;

      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>

        // Fluid harmonic wave displacement (flowing molten glass)
        float freq = uFrequency / max(0.3, uViscosity);
        float w1 = sin(transformed.x * freq + uTime * 1.6) * cos(transformed.z * freq + uTime * 1.3);
        float w2 = sin(transformed.y * freq * 1.5 - uTime * 2.0) * 0.5;
        float w3 = sin((transformed.x + transformed.y + transformed.z) * freq * 0.8 + uTime * 2.2) * 0.35;
        float fluidDisplace = (w1 + w2 + w3) * uAmplitude;

        // Interactive ripple pulse from click/tap
        float distToRipple = length(transformed - uRippleOrigin);
        float rippleSpeed = 4.5;
        float rippleWave = sin(max(0.0, uRippleTime * rippleSpeed - distToRipple * 5.5) * 3.14159);
        float rippleAtten = exp(-uRippleTime * 1.6) * exp(-distToRipple * 1.4);
        float rippleDisplace = rippleWave * rippleAtten * 0.32;

        transformed += normal * (fluidDisplace + rippleDisplace);
        vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        vWorldNormal = normalize((modelMatrix * vec4(normal, 0.0)).xyz);
        `
      );

      shader.fragmentShader = `
        uniform float uTime;
        uniform float uDispersion;
        uniform vec3 uGlassColor;
        uniform vec3 uAttenuationColor;
        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        ${shader.fragmentShader}
      `;

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <dithering_fragment>',
        `
        #include <dithering_fragment>

        // Optical Fresnel rim glow & chromatic liquid glass highlights
        vec3 viewDir = normalize(cameraPosition - vWorldPos);
        float cosTheta = max(0.0, dot(vWorldNormal, viewDir));
        float fresnelRim = pow(1.0 - cosTheta, 3.5);

        // Prismatic dispersion edge shimmer
        vec3 prismGlow = mix(uAttenuationColor, vec3(0.5, 0.85, 1.0), fresnelRim) * fresnelRim * (1.2 + uDispersion * 1.4);
        gl_FragColor.rgb += prismGlow * 0.55;
        `
      );
    };

    const glassMesh = new THREE.Mesh(glassGeometry, glassMaterial);
    glassMesh.position.set(0, 0.85, 0);
    glassMesh.castShadow = !isSoftwareGl;
    glassMesh.receiveShadow = !isSoftwareGl;
    heroGroup.add(glassMesh);
    materialsRef.current.glassMaterial = glassMaterial;

    // Part 2: Internal Floating Mercury / Chromatic Fluid Core
    const coreGeometry = new THREE.SphereGeometry(0.68, isSoftwareGl ? 24 : 40, isSoftwareGl ? 20 : 32);
    const coreMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(preset.coreColor),
      metalness: 0.98,
      roughness: 0.06,
    });
    const coreMesh = new THREE.Mesh(coreGeometry, coreMaterial);
    coreMesh.position.set(0, 0.85, 0);
    heroGroup.add(coreMesh);
    materialsRef.current.coreMaterial = coreMaterial;

    // Part 3: Equatorial Prismatic Optical Ring
    const ringGeometry = new THREE.TorusGeometry(1.75, 0.038, 16, 64);
    const ringMaterial = new THREE.MeshStandardMaterial({
      color: '#e2e8f0',
      metalness: 0.94,
      roughness: 0.12,
    });
    const ringMesh = new THREE.Mesh(ringGeometry, ringMaterial);
    ringMesh.rotation.x = Math.PI / 2;
    ringMesh.position.set(0, 0.85, 0);
    heroGroup.add(ringMesh);
    materialsRef.current.ringMaterial = ringMaterial;

    // Part 4: Machined Titanium Pedestal (Beveled bottom structure)
    const baseGroup = new THREE.Group();
    baseGroup.position.set(0, 0, 0);

    const knurledTexture = createKnurledNormalMap();
    knurledTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const pedestalGeom = new THREE.CylinderGeometry(1.3, 1.48, 0.18, 48);
    const pedestalMat = new THREE.MeshStandardMaterial({
      color: '#1a2233',
      metalness: 0.9,
      roughness: 0.22,
      normalMap: knurledTexture,
      normalScale: new THREE.Vector2(0.5, 0.5),
    });
    const pedestalMesh = new THREE.Mesh(pedestalGeom, pedestalMat);
    pedestalMesh.position.y = 0.09;
    pedestalMesh.receiveShadow = !isSoftwareGl;
    pedestalMesh.castShadow = !isSoftwareGl;
    baseGroup.add(pedestalMesh);

    // Part 5: Chamfered Top Collar on Pedestal
    const collarGeom = new THREE.CylinderGeometry(1.05, 1.3, 0.08, 48);
    const collarMat = new THREE.MeshStandardMaterial({
      color: '#334155',
      metalness: 0.96,
      roughness: 0.1,
    });
    const collarMesh = new THREE.Mesh(collarGeom, collarMat);
    collarMesh.position.y = 0.22;
    collarMesh.receiveShadow = !isSoftwareGl;
    baseGroup.add(collarMesh);

    // Part 6: Magnetic Emitter Ring
    const emitterGeom = new THREE.TorusGeometry(1.08, 0.024, 16, 48);
    const emitterMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(preset.coreColor),
      emissive: new THREE.Color(preset.coreColor),
      emissiveIntensity: 0.9,
      metalness: 0.5,
      roughness: 0.2,
    });
    const emitterMesh = new THREE.Mesh(emitterGeom, emitterMat);
    emitterMesh.rotation.x = Math.PI / 2;
    emitterMesh.position.y = 0.26;
    baseGroup.add(emitterMesh);
    materialsRef.current.emitterMaterial = emitterMat;
    heroGroup.add(baseGroup);

    // Parts 7, 8, 9: Orbiting Viscous Satellite Micro-Droplets
    const satelliteCount = 3;
    const satellites: THREE.Mesh[] = [];
    const satGeom = new THREE.SphereGeometry(0.12, 24, 24);
    const satMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(preset.attenuationColor),
      transmission: isSoftwareGl ? 0.35 : 0.9,
      transparent: true,
      opacity: isSoftwareGl ? 0.6 : 0.95,
      ior: 1.48,
      roughness: 0.04,
      metalness: 0.1,
      thickness: 1.2,
    });
    materialsRef.current.satMaterial = satMat;

    for (let i = 0; i < satelliteCount; i++) {
      const sat = new THREE.Mesh(satGeom, satMat);
      heroGroup.add(sat);
      satellites.push(sat);
    }

    // Part 10: Ground Contact Shadow & Caustic Plane
    const shadowGeo = new THREE.PlaneGeometry(5.2, 5.2);
    const shadowTexture = createContactShadowTexture();
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.005;
    heroGroup.add(shadowMesh);

    // Pre-warm shaders
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Ripple triggering logic on pointer interaction
    const triggerRippleAt = (hitPoint?: THREE.Vector3) => {
      uniformsRef.current.uRippleTime.value = 0.0;
      if (hitPoint) {
        uniformsRef.current.uRippleOrigin.value.copy(hitPoint);
      } else {
        uniformsRef.current.uRippleOrigin.value.set(
          (Math.random() - 0.5) * 0.8,
          0.85 + (Math.random() - 0.5) * 0.6,
          (Math.random() - 0.5) * 0.8
        );
      }
      soundFx.playDropletRipple();
    };
    triggerRippleRef.current = () => triggerRippleAt();

    // Pointer events for direct interactive liquid touching
    const onPointerDown = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      _mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      _mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      _raycaster.setFromCamera(_mouse, camera);
      const intersects = _raycaster.intersectObject(glassMesh);

      if (intersects.length > 0) {
        triggerRippleAt(intersects[0].point);
      }
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    // 8. Animation & Render Loop
    let frameId = 0;
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      const now = performance.now();
      const dt = Math.min(0.1, (now - lastTime) / 1000);
      lastTime = now;

      // Advance uniforms by elapsed delta
      uniformsRef.current.uTime.value += dt;
      uniformsRef.current.uRippleTime.value += dt;

      const elapsed = uniformsRef.current.uTime.value;

      // Turntable rotation
      if (autoRotate && !isSoftwareGl) {
        heroGroup.rotation.y += dt * 0.25;
      }

      // Dynamic motion of internal chromatic core (counter-rotation and gentle breathing)
      coreMesh.rotation.y -= dt * 0.45;
      coreMesh.rotation.x = Math.sin(elapsed * 1.2) * 0.15;
      coreMesh.position.y = 0.85 + Math.sin(elapsed * 1.8) * 0.04;

      // Prismatic ring precession
      ringMesh.rotation.z = elapsed * 0.3;
      ringMesh.rotation.x = Math.PI / 2 + Math.sin(elapsed * 1.5) * 0.12;

      // Satellite droplets orbital paths
      satellites.forEach((sat, idx) => {
        const angle = elapsed * (0.8 + idx * 0.3) + (idx * Math.PI * 2) / satelliteCount;
        const radius = 2.0 + Math.sin(elapsed * 1.5 + idx) * 0.18;
        sat.position.set(
          Math.cos(angle) * radius,
          0.85 + Math.sin(elapsed * 2.5 + idx * 2.0) * 0.45,
          Math.sin(angle) * radius
        );
        sat.scale.setScalar(0.9 + Math.sin(elapsed * 3.0 + idx) * 0.15);
      });

      // Controls update with exponential damping
      controls.update();

      // Render
      renderer.render(scene, camera);

      // FPS tracking
      frameCount++;
      if (now - fpsTimer >= 1000) {
        onFpsUpdate?.(frameCount, renderer.info.render.triangles);
        frameCount = 0;
        fpsTimer = now;
      }

      // Schedule next frame
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    // Start loop
    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    // 9. Resize handler
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      if (isSoftwareGl) {
        clearTimeout(frameId);
      } else {
        cancelAnimationFrame(frameId);
      }
      controls.dispose();
      renderer.dispose();
      glassGeometry.dispose();
      glassMaterial.dispose();
      coreGeometry.dispose();
      coreMaterial.dispose();
      ringGeometry.dispose();
      ringMaterial.dispose();
      pedestalGeom.dispose();
      pedestalMat.dispose();
      collarGeom.dispose();
      collarMat.dispose();
      emitterGeom.dispose();
      emitterMat.dispose();
      satGeom.dispose();
      satMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      knurledTexture.dispose();
      shadowTexture.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing overflow-hidden"
      data-testid="liquid-glass-viewport"
    />
  );
};
