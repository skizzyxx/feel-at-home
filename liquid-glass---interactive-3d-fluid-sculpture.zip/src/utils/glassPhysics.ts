/**
 * Pure physics and optical calculation utilities for Liquid Glass simulation.
 * Decoupled from DOM/UI for deterministic unit testing.
 */

export interface GlassPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  color: string;
  attenuationColor: string;
  attenuationDistance: number;
  ior: number;
  roughness: number;
  metalness: number;
  clearcoat: number;
  clearcoatRoughness: number;
  transmission: number;
  thickness: number;
  viscosity: number;
  waveAmplitude: number;
  waveFrequency: number;
  coreColor: string;
}

export const GLASS_PRESETS: GlassPreset[] = [
  {
    id: 'borosilicate-clear',
    name: 'Pure Borosilicate',
    category: 'Optical Crown',
    description: 'High-clarity optical glass with ultra-low dispersion and luminous caustics.',
    color: '#ffffff',
    attenuationColor: '#e0f2fe',
    attenuationDistance: 2.2,
    ior: 1.52,
    roughness: 0.04,
    metalness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.02,
    transmission: 0.98,
    thickness: 2.0,
    viscosity: 1.2,
    waveAmplitude: 0.12,
    waveFrequency: 2.4,
    coreColor: '#38bdf8',
  },
  {
    id: 'electric-sapphire',
    name: 'Electric Sapphire',
    category: 'Synthetic Crystal',
    description: 'Deep cobalt-cyan optical density with radiant refractive depth.',
    color: '#0284c7',
    attenuationColor: '#0ea5e9',
    attenuationDistance: 1.1,
    ior: 1.77,
    roughness: 0.08,
    metalness: 0.1,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
    transmission: 0.94,
    thickness: 2.6,
    viscosity: 2.0,
    waveAmplitude: 0.16,
    waveFrequency: 1.8,
    coreColor: '#67e8f9',
  },
  {
    id: 'rose-quartz',
    name: 'Molten Rose Quartz',
    category: 'Silica Gemstone',
    description: 'Warm champagne-pink vitreous crystal with soft internal glow.',
    color: '#f43f5e',
    attenuationColor: '#fda4af',
    attenuationDistance: 1.4,
    ior: 1.54,
    roughness: 0.06,
    metalness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.03,
    transmission: 0.95,
    thickness: 2.2,
    viscosity: 1.5,
    waveAmplitude: 0.14,
    waveFrequency: 2.0,
    coreColor: '#fb7185',
  },
  {
    id: 'cosmic-emerald',
    name: 'Cosmic Emerald',
    category: 'Beryl Silicate',
    description: 'Hyper-vibrant emerald refraction with intense sub-surface caustics.',
    color: '#059669',
    attenuationColor: '#34d399',
    attenuationDistance: 1.3,
    ior: 1.62,
    roughness: 0.05,
    metalness: 0.08,
    clearcoat: 1.0,
    clearcoatRoughness: 0.03,
    transmission: 0.96,
    thickness: 2.4,
    viscosity: 1.8,
    waveAmplitude: 0.15,
    waveFrequency: 2.2,
    coreColor: '#6ee7b7',
  },
  {
    id: 'obsidian-liquid',
    name: 'Molten Obsidian',
    category: 'Volcanic Glass',
    description: 'Smoked tinted volcanic glass with iridescent liquid metallic core.',
    color: '#18181b',
    attenuationColor: '#3f3f46',
    attenuationDistance: 0.8,
    ior: 1.68,
    roughness: 0.12,
    metalness: 0.45,
    clearcoat: 1.0,
    clearcoatRoughness: 0.06,
    transmission: 0.85,
    thickness: 3.0,
    viscosity: 2.8,
    waveAmplitude: 0.09,
    waveFrequency: 1.4,
    coreColor: '#f59e0b',
  },
];

/**
 * Calculates Fresnel reflectance using Schlick's approximation.
 * @param cosTheta Angle between normal and view vector (0 to 1)
 * @param ior Index of Refraction (e.g. 1.52 for crown glass)
 */
export function calculateFresnel(cosTheta: number, ior: number): number {
  const clampedCos = Math.max(0, Math.min(1, cosTheta));
  const r0 = Math.pow((1.0 - ior) / (1.0 + ior), 2);
  return r0 + (1.0 - r0) * Math.pow(1.0 - clampedCos, 5);
}

/**
 * Computes multi-harmonic fluid wave displacement for liquid surface deformation.
 * @param x Position x
 * @param y Position y
 * @param z Position z
 * @param time Elapsed time in seconds
 * @param frequency Base frequency
 * @param amplitude Base amplitude
 * @param viscosity Fluid damping factor
 */
export function computeWaveHarmonics(
  x: number,
  y: number,
  z: number,
  time: number,
  frequency: number,
  amplitude: number,
  viscosity: number
): number {
  const scaledFreq = frequency / Math.max(0.2, viscosity);
  const w1 = Math.sin(x * scaledFreq + time * 1.5) * Math.cos(z * scaledFreq + time * 1.2);
  const w2 = Math.sin(y * scaledFreq * 1.4 - time * 1.8) * 0.5;
  const w3 = Math.sin((x + y + z) * scaledFreq * 0.7 + time * 2.1) * 0.35;
  return (w1 + w2 + w3) * amplitude;
}

/**
 * Linear color interpolation between two hex codes.
 */
export function interpolateColorHex(hex1: string, hex2: string, factor: number): string {
  const t = Math.max(0, Math.min(1, factor));
  const c1 = parseInt(hex1.replace('#', ''), 16);
  const c2 = parseInt(hex2.replace('#', ''), 16);

  const r1 = (c1 >> 16) & 255;
  const g1 = (c1 >> 8) & 255;
  const b1 = c1 & 255;

  const r2 = (c2 >> 16) & 255;
  const g2 = (c2 >> 8) & 255;
  const b2 = c2 & 255;

  const r = Math.round(r1 + (r2 - r1) * t);
  const g = Math.round(g1 + (g2 - g1) * t);
  const b = Math.round(b1 + (b2 - b1) * t);

  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/**
 * Damps an animation value smoothly towards a target with frame-rate independence.
 */
export function exponentialDamp(current: number, target: number, lambda: number, dt: number): number {
  return target + (current - target) * Math.exp(-lambda * dt);
}
