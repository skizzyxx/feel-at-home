/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect } from 'react';
import { LiquidGlassCanvas } from './components/LiquidGlassCanvas';
import { ControlDock } from './components/ControlDock';
import { HeaderBar } from './components/HeaderBar';
import { GlassPreset, GLASS_PRESETS } from './utils/glassPhysics';
import { soundFx } from './utils/audioSynthesizer';

export default function App() {
  const [currentPreset, setCurrentPreset] = useState<GlassPreset>(GLASS_PRESETS[0]);
  const [viscosity, setViscosity] = useState<number>(GLASS_PRESETS[0].viscosity);
  const [waveAmplitude, setWaveAmplitude] = useState<number>(GLASS_PRESETS[0].waveAmplitude);
  const [waveFrequency, setWaveFrequency] = useState<number>(GLASS_PRESETS[0].waveFrequency);
  const [ior, setIor] = useState<number>(GLASS_PRESETS[0].ior);
  const [roughness, setRoughness] = useState<number>(GLASS_PRESETS[0].roughness);
  const [dispersion, setDispersion] = useState<number>(0.35);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [cameraPreset, setCameraPreset] = useState<'macro' | 'studio' | 'top' | 'reset' | null>(null);
  const [rippleTrigger, setRippleTrigger] = useState<number>(0);
  const [fps, setFps] = useState<number>(60);
  const [triangles, setTriangles] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Update parameters when selecting a preset
  const handleSelectPreset = useCallback((newPreset: GlassPreset) => {
    setCurrentPreset(newPreset);
    setViscosity(newPreset.viscosity);
    setWaveAmplitude(newPreset.waveAmplitude);
    setWaveFrequency(newPreset.waveFrequency);
    setIor(newPreset.ior);
    setRoughness(newPreset.roughness);
  }, []);

  const handleTriggerRipple = useCallback(() => {
    setRippleTrigger((prev) => prev + 1);
  }, []);

  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      soundFx.setMuted(next);
      return next;
    });
  }, []);

  const handleToggleAutoRotate = useCallback(() => {
    setAutoRotate((prev) => !prev);
  }, []);

  const handleSelectCameraPreset = useCallback((preset: 'macro' | 'studio' | 'top' | 'reset') => {
    setCameraPreset(preset);
  }, []);

  const handleCameraPresetSettled = useCallback(() => {
    setCameraPreset(null);
  }, []);

  const handleFpsUpdate = useCallback((newFps: number, newTriangles: number) => {
    setFps(newFps);
    setTriangles(newTriangles);
  }, []);

  // Keyboard shortcut listener ('r' for ripple)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'r' || e.key === 'R') {
        handleTriggerRipple();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleTriggerRipple]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#08090c] text-slate-100 select-none">
      {/* 3D WebGL Viewport */}
      <LiquidGlassCanvas
        preset={currentPreset}
        viscosity={viscosity}
        waveAmplitude={waveAmplitude}
        waveFrequency={waveFrequency}
        ior={ior}
        roughness={roughness}
        dispersion={dispersion}
        autoRotate={autoRotate}
        cameraPreset={cameraPreset}
        onCameraPresetSettled={handleCameraPresetSettled}
        onFpsUpdate={handleFpsUpdate}
        rippleTrigger={rippleTrigger}
      />

      {/* Top Header Bar */}
      <HeaderBar
        currentPreset={currentPreset}
        fps={fps}
        triangles={triangles}
      />

      {/* Bottom Collapsible Control Dock */}
      <ControlDock
        currentPreset={currentPreset}
        onSelectPreset={handleSelectPreset}
        viscosity={viscosity}
        onViscosityChange={setViscosity}
        waveAmplitude={waveAmplitude}
        onWaveAmplitudeChange={setWaveAmplitude}
        waveFrequency={waveFrequency}
        onWaveFrequencyChange={setWaveFrequency}
        ior={ior}
        onIorChange={setIor}
        roughness={roughness}
        onRoughnessChange={setRoughness}
        dispersion={dispersion}
        onDispersionChange={setDispersion}
        autoRotate={autoRotate}
        onToggleAutoRotate={handleToggleAutoRotate}
        onTriggerRipple={handleTriggerRipple}
        onSelectCameraPreset={handleSelectCameraPreset}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />
    </main>
  );
}
