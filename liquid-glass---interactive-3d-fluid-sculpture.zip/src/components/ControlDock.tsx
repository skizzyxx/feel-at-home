import React, { useState } from 'react';
import {
  Sparkles,
  Droplets,
  Eye,
  Camera,
  ChevronDown,
  ChevronUp,
  RotateCw,
  Waves,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GlassPreset, GLASS_PRESETS } from '../utils/glassPhysics';
import { soundFx } from '../utils/audioSynthesizer';

interface ControlDockProps {
  currentPreset: GlassPreset;
  onSelectPreset: (preset: GlassPreset) => void;
  viscosity: number;
  onViscosityChange: (val: number) => void;
  waveAmplitude: number;
  onWaveAmplitudeChange: (val: number) => void;
  waveFrequency: number;
  onWaveFrequencyChange: (val: number) => void;
  ior: number;
  onIorChange: (val: number) => void;
  roughness: number;
  onRoughnessChange: (val: number) => void;
  dispersion: number;
  onDispersionChange: (val: number) => void;
  autoRotate: boolean;
  onToggleAutoRotate: () => void;
  onTriggerRipple: () => void;
  onSelectCameraPreset: (preset: 'macro' | 'studio' | 'top' | 'reset') => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

type TabType = 'presets' | 'fluid' | 'optics' | 'camera';

export const ControlDock: React.FC<ControlDockProps> = ({
  currentPreset,
  onSelectPreset,
  viscosity,
  onViscosityChange,
  waveAmplitude,
  onWaveAmplitudeChange,
  waveFrequency,
  onWaveFrequencyChange,
  ior,
  onIorChange,
  roughness,
  onRoughnessChange,
  dispersion,
  onDispersionChange,
  autoRotate,
  onToggleAutoRotate,
  onTriggerRipple,
  onSelectCameraPreset,
  isMuted,
  onToggleMute,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('presets');
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  return (
    <div
      className={`fixed bottom-5 left-1/2 -translate-x-1/2 w-full max-w-[940px] px-4 z-40 transition-transform duration-300 ease-out ${
        isCollapsed ? 'translate-y-[calc(100%-42px)]' : 'translate-y-0'
      }`}
    >
      {/* Collapse/Expand Toggle Tab */}
      <div className="flex justify-center mb-1">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          aria-label={isCollapsed ? 'Show Controls Dock' : 'Hide Controls Dock'}
          className="flex items-center gap-1.5 px-3 py-1 bg-[#121620] hover:bg-[#1a2130] text-slate-300 hover:text-white text-xs font-medium rounded-t-lg border border-b-0 border-slate-800 transition-colors cursor-pointer shadow-lg"
        >
          {isCollapsed ? (
            <>
              <ChevronUp size={14} />
              <span>Expand Controls</span>
            </>
          ) : (
            <>
              <ChevronDown size={14} />
              <span>Collapse HUD</span>
            </>
          )}
        </button>
      </div>

      {/* Main Dock Container - Solid surface, no backdrop-filter to prevent WebGL slow down */}
      <div className="bg-[#10141d] border border-slate-800/90 rounded-2xl shadow-2xl p-4 text-slate-200">
        {/* Navigation Tabs Bar */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3 gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-[#0b0e14] p-1 rounded-xl border border-slate-800/80">
            <button
              onClick={() => setActiveTab('presets')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'presets'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Sparkles size={13} />
              <span>Glass Formula</span>
            </button>

            <button
              onClick={() => setActiveTab('fluid')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'fluid'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Droplets size={13} />
              <span>Fluid Kinetics</span>
            </button>

            <button
              onClick={() => setActiveTab('optics')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'optics'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Eye size={13} />
              <span>Optics & Refraction</span>
            </button>

            <button
              onClick={() => setActiveTab('camera')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'camera'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Camera size={13} />
              <span>Camera</span>
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onTriggerRipple}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-sky-300 border border-slate-700/60 transition-colors cursor-pointer"
              title="Generate a fluid ripple wave in the liquid glass"
            >
              <Waves size={13} />
              <span>Pulse Ripple</span>
            </button>

            <button
              onClick={onToggleMute}
              className={`p-1.5 rounded-lg text-xs border transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-slate-800/50 text-slate-400 border-slate-700/50'
                  : 'bg-slate-800/80 text-sky-400 border-sky-500/40'
              }`}
              title={isMuted ? 'Unmute procedural crystal resonance' : 'Mute sound'}
              aria-label={isMuted ? 'Unmute sound' : 'Mute sound'}
            >
              {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            </button>
          </div>
        </div>

        {/* Tab 1: Presets Selection */}
        {activeTab === 'presets' && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {GLASS_PRESETS.map((p) => {
              const isSelected = p.id === currentPreset.id;
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    onSelectPreset(p);
                    soundFx.playGlassChime(1100, 0.9);
                  }}
                  className={`flex flex-col text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#182030] border-sky-500/80 ring-1 ring-sky-500/50'
                      : 'bg-[#0d1017] border-slate-800/80 hover:border-slate-700 hover:bg-[#131722]'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/20 shadow-sm shrink-0"
                      style={{ backgroundColor: p.attenuationColor }}
                    />
                    <span className="text-xs font-semibold text-slate-100 truncate">
                      {p.name}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 line-clamp-1">
                    {p.category}
                  </span>
                  <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400 font-mono-tech">
                    <span>IOR {p.ior.toFixed(2)}</span>
                    <span>T {(p.transmission * 100).toFixed(0)}%</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* Tab 2: Fluid Kinetics Controls */}
        {activeTab === 'fluid' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Viscosity (Damping)</span>
                <span className="text-sky-400 font-mono-tech">{viscosity.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.4"
                max="3.5"
                step="0.05"
                value={viscosity}
                onChange={(e) => onViscosityChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                Low = quick fluid ripples; High = molten viscous honey
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Wave Amplitude</span>
                <span className="text-sky-400 font-mono-tech">{waveAmplitude.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.30"
                step="0.01"
                value={waveAmplitude}
                onChange={(e) => onWaveAmplitudeChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                Height and depth of molten surface undulations
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Wave Frequency</span>
                <span className="text-sky-400 font-mono-tech">{waveFrequency.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="4.0"
                step="0.1"
                value={waveFrequency}
                onChange={(e) => onWaveFrequencyChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                Spatial density of harmonic ripple crests
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Optics & Glass Refraction Controls */}
        {activeTab === 'optics' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Refractive Index (IOR)</span>
                <span className="text-sky-400 font-mono-tech">{ior.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="1.10"
                max="2.42"
                step="0.02"
                value={ior}
                onChange={(e) => onIorChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                1.33 Water, 1.52 Crown Glass, 2.42 Diamond
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Surface Roughness (Frosting)</span>
                <span className="text-sky-400 font-mono-tech">{roughness.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.40"
                step="0.01"
                value={roughness}
                onChange={(e) => onRoughnessChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                Zero = specular mirror clarity; Higher = frosted satin
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Dispersion (Prismatic Glow)</span>
                <span className="text-sky-400 font-mono-tech">{dispersion.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={dispersion}
                onChange={(e) => onDispersionChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <p className="text-[10px] text-slate-400">
                Prismatic chromatic separation intensity
              </p>
            </div>
          </div>
        )}

        {/* Tab 4: Camera & Orbit Controls */}
        {activeTab === 'camera' && (
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-400 mr-1">Camera Angles:</span>
              <button
                onClick={() => onSelectCameraPreset('macro')}
                className="px-3 py-1.5 bg-[#0d1017] hover:bg-slate-800 text-xs text-slate-200 rounded-lg border border-slate-800 transition-colors cursor-pointer"
              >
                Macro Focus
              </button>
              <button
                onClick={() => onSelectCameraPreset('studio')}
                className="px-3 py-1.5 bg-[#0d1017] hover:bg-slate-800 text-xs text-slate-200 rounded-lg border border-slate-800 transition-colors cursor-pointer"
              >
                Studio 45°
              </button>
              <button
                onClick={() => onSelectCameraPreset('top')}
                className="px-3 py-1.5 bg-[#0d1017] hover:bg-slate-800 text-xs text-slate-200 rounded-lg border border-slate-800 transition-colors cursor-pointer"
              >
                Top Orthogonal
              </button>
              <button
                onClick={() => onSelectCameraPreset('reset')}
                className="px-3 py-1.5 bg-[#0d1017] hover:bg-slate-800 text-xs text-slate-200 rounded-lg border border-slate-800 transition-colors cursor-pointer"
              >
                Reset Default
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onToggleAutoRotate}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                  autoRotate
                    ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                    : 'bg-[#0d1017] text-slate-400 border-slate-800'
                }`}
              >
                <RotateCw size={13} className={autoRotate ? 'text-sky-400' : ''} />
                <span>Auto-Turntable</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
