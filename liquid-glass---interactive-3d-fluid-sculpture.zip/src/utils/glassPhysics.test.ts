import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateFresnel,
  computeWaveHarmonics,
  interpolateColorHex,
  exponentialDamp,
  GLASS_PRESETS,
} from './glassPhysics';

test('Fresnel reflection calculates valid bounds between 0 and 1', () => {
  // Normal incidence (cosTheta = 1.0)
  const normalReflectance = calculateFresnel(1.0, 1.52);
  assert.ok(normalReflectance > 0.03 && normalReflectance < 0.06);

  // Grazing incidence (cosTheta = 0.0)
  const grazingReflectance = calculateFresnel(0.0, 1.52);
  assert.equal(Math.round(grazingReflectance * 100) / 100, 1.0);

  // Intermediate angle
  const midReflectance = calculateFresnel(0.5, 1.52);
  assert.ok(midReflectance > normalReflectance && midReflectance < 1.0);
});

test('Wave harmonics return bounded continuous values', () => {
  const displacement1 = computeWaveHarmonics(1.0, 0.5, -0.2, 0.0, 2.0, 0.15, 1.0);
  const displacement2 = computeWaveHarmonics(1.0, 0.5, -0.2, 0.1, 2.0, 0.15, 1.0);

  assert.ok(typeof displacement1 === 'number');
  assert.ok(Math.abs(displacement1) <= 0.3); // Within maximum harmonic envelope
  assert.notEqual(displacement1, displacement2); // Changes over time
});

test('Hex color interpolation blends correctly', () => {
  const black = '#000000';
  const white = '#ffffff';

  assert.equal(interpolateColorHex(black, white, 0), '#000000');
  assert.equal(interpolateColorHex(black, white, 1), '#ffffff');
  assert.equal(interpolateColorHex(black, white, 0.5), '#808080');
});

test('Exponential damping moves towards target without overshoot', () => {
  const current = 10;
  const target = 20;
  const next = exponentialDamp(current, target, 5, 0.016);

  assert.ok(next > current);
  assert.ok(next <= target);
});

test('Glass presets list contains valid unique configurations', () => {
  assert.ok(GLASS_PRESETS.length >= 5);
  const ids = new Set(GLASS_PRESETS.map((p) => p.id));
  assert.equal(ids.size, GLASS_PRESETS.length);

  for (const preset of GLASS_PRESETS) {
    assert.ok(preset.ior >= 1.0 && preset.ior <= 2.5);
    assert.ok(preset.transmission >= 0.5 && preset.transmission <= 1.0);
    assert.ok(preset.viscosity > 0);
  }
});
