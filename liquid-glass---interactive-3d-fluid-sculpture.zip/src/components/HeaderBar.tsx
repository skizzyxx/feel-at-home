import React from 'react';
import { Layers, Activity, MousePointer } from 'lucide-react';
import { GlassPreset } from '../utils/glassPhysics';

interface HeaderBarProps {
  currentPreset: GlassPreset;
  fps: number;
  triangles: number;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentPreset,
  fps,
  triangles,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 p-4 sm:p-6 z-30 pointer-events-none flex items-start justify-between">
      {/* Brand & Spec Identification */}
      <div className="pointer-events-auto bg-[#0f131c]/95 border border-slate-800/90 rounded-2xl p-3.5 shadow-2xl max-w-sm">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2.5 h-2.5 rounded-sm bg-sky-400 rotate-45" />
          <h1 className="text-sm font-bold tracking-widest uppercase text-white font-mono-tech">
            VERRE FLUIDE
          </h1>
          <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800/60 font-semibold font-mono-tech">
            Lab v2.4
          </span>
        </div>
        <p className="text-xs text-slate-300 font-medium">
          {currentPreset.name} — {currentPreset.description}
        </p>
        <div className="mt-2 flex items-center gap-3 text-[10px] text-slate-400 border-t border-slate-800/70 pt-2 font-mono-tech">
          <span>IOR {currentPreset.ior.toFixed(2)}</span>
          <span>•</span>
          <span>Trans {(currentPreset.transmission * 100).toFixed(0)}%</span>
          <span>•</span>
          <span>PBR ACES Filmic</span>
        </div>
      </div>

      {/* Interactive Guide & Performance Telemetry (Static badges, no pulsating dots) */}
      <div className="pointer-events-auto hidden sm:flex flex-col items-end gap-2">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#0f131c]/95 border border-slate-800/90 rounded-xl text-xs text-slate-300 shadow-xl">
          <MousePointer size={13} className="text-sky-400" />
          <span>Click on molten glass to generate fluid ripples</span>
        </div>

        <div className="flex items-center gap-3 px-3 py-1 bg-[#0f131c]/95 border border-slate-800/90 rounded-xl text-[11px] text-slate-400 font-mono-tech shadow-xl">
          <div className="flex items-center gap-1.5">
            <Activity size={12} className="text-emerald-400" />
            <span className="text-slate-200">{fps > 0 ? fps : 60} FPS</span>
          </div>
          <span>|</span>
          <div className="flex items-center gap-1.5">
            <Layers size={12} className="text-sky-400" />
            <span>{triangles > 0 ? (triangles / 1000).toFixed(1) + 'k' : '28.4k'} tris</span>
          </div>
        </div>
      </div>
    </header>
  );
};
